from django.urls import path

from getJsonData import views

urlpatterns = [
    path('', views.MainPage.as_view()),
    path('day_ahead/<areas>/', views.GetDayAheadData.as_view()),
    path('source/<areas>/<source>/', views.GetCountryData.as_view())
]
