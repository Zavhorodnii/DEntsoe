import os
from datetime import datetime, timedelta
from pathlib import Path
import json

import pytz as pytz
from django.core import serializers
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.views import View
from .models import Country, Source, Data, ProcessType, DayAheadData

base_path = Path(os.path.abspath(__file__)).parents[2]


class MainPage(View):
    def get(self, response):
        info = "You need to open url: " \
               "<br> 1. http://127.0.0.1:8000/day_ahead/{{country}}" \
               "<br> 2. http://127.0.0.1:8000/source/{{country}}/{{code_source}}/"
        return HttpResponse(info)


class GetCountryData(View):
    def get(self, request, areas, source):
        current_year = datetime.now().year
        # print(F"base_path = {base_path}")
        # files_path = str(base_path) + '\cron\data\years\\'
        files_path = str(base_path) + '/cron/data/years/source/'

        response_data = {}
        response_data['country'] = areas
        response_data['source'] = source
        # print(files_path)

        data = Country.objects.filter(country=areas).count()

        if data == 0:
            dir_list = os.listdir(files_path)
            for file in dir_list:
                with open(files_path + file) as f:
                    dict_file = json.loads(f.read())
                    try:
                        area = dict_file['GL_MarketDocument']['TimeSeries'][0]['inBiddingZone_Domain.mRID']['#text']
                        psrType = dict_file['GL_MarketDocument']['TimeSeries'][0]['MktPSRType']['psrType']
                        period_start = datetime.strptime(
                            dict_file['GL_MarketDocument']['TimeSeries'][0]['Period']['timeInterval']['start'],
                            "%Y-%m-%dT%H:%MZ"
                        )
                        point = dict_file['GL_MarketDocument']['TimeSeries'][0]['Period']['Point']
                        # print('exist')
                    except:
                        area = dict_file['GL_MarketDocument']['TimeSeries']['inBiddingZone_Domain.mRID']['#text']
                        psrType = dict_file['GL_MarketDocument']['TimeSeries']['MktPSRType']['psrType']
                        period_start = datetime.strptime(
                            dict_file['GL_MarketDocument']['TimeSeries']['Period']['timeInterval']['start'],
                            "%Y-%m-%dT%H:%MZ"
                        )
                        point = dict_file['GL_MarketDocument']['TimeSeries']['Period']['Point']
                        # print('not exist')

                    # print(F"period_start = {period_start}")

                    if Country.objects.filter(country=area).count() == 0:
                        p = Country(country=area)
                        p.save()

                    area_id = Country.objects.filter(country=area).values_list('id', flat=True)[0]
                    psrType_count = Source.objects.filter(
                        country=area_id,
                        source=psrType,
                    ).count()

                    if psrType_count == 0:
                        p = Source(
                            country=Country.objects.get(pk=area_id),
                            source=psrType
                        )
                        p.save()

                    count_index = 0
                    quantity = 0
                    tz = dict_file['GL_MarketDocument']['time_Period.timeInterval']['tz']

                    local_tz = pytz.timezone(tz)
                    period_start = local_tz.localize(period_start)

                    for x in point:
                        quantity += int(x['quantity'])
                        count_index += 1
                        if count_index == 4:
                            period_start = period_start + timedelta(hours=1)

                            source_id = Source.objects.filter(
                                country=area_id,
                                source=psrType,
                            ).values_list('id', flat=True)[0]

                            data_id = Data.objects.filter(
                                source=Source.objects.get(pk=source_id),
                                datetime=period_start,
                            ).values_list('id', flat=True)

                            if len(data_id) == 0:
                                p = Data(
                                    source=Source.objects.get(pk=source_id),
                                    datetime=period_start,
                                    data=quantity / 4
                                )
                                p.save()
                            quantity = 0
                            count_index = 0
                        # print(F"x = {x}")
                os.remove(files_path + file)

        data = self.getDataFromDB(areas, source)

        # response_data['data'] = serializers.serialize("json", data)

        if data == 'none':
            response_data['data'] = data
        else:
            for item in list(data):
                item['date'] = item['datetime'].strftime("%Y-%m-%dT%H:%M:%SZ")
                item.pop('datetime')
            response_data['data'] = list(data)

        return HttpResponse(json.dumps(response_data), content_type="application/json")

    def getDataFromDB(self, area, source):
        try:
            area_id = Country.objects.filter(country=area).values_list('id', flat=True)[0]
        except:
            return 'none'
        source_id = Source.objects.filter(
            country=area_id,
            source=source,
        ).values_list('id', flat=True)[0]
        data = Data.objects.filter(
            source=Source.objects.get(pk=source_id),
        ).values('id', 'datetime', 'data').order_by('datetime')
        return data


class GetDayAheadData(View):
    def get(self, request, areas):
        current_year = datetime.now().year
        # print(F"base_path = {base_path}")
        # files_path = str(base_path) + '\cron\data\years\day_ahead\\'
        files_path = str(base_path) + '/cron/data/years/day_ahead/'

        response_data = {}
        response_data['country'] = areas
        # print(files_path)

        # data = Country.objects.filter(country=areas).count()

        # if data == 0:
        dir_list = os.listdir(files_path)
        for file in dir_list:

            count = 1
            with open(files_path + file) as f:
                dict_file = json.loads(f.read())

                tz = dict_file['GL_MarketDocument']['time_Period.timeInterval']['tz']

                for day in dict_file['GL_MarketDocument']['TimeSeries']:
                    area = day['outBiddingZone_Domain.mRID']['#text']
                    process_type = day['outBiddingZone_Domain.mRID']['@codingScheme']
                    if Country.objects.filter(country=area).count() == 0:
                        p = Country(country=area)
                        p.save()

                    area_id = Country.objects.filter(country=area).values_list('id', flat=True)[0]
                    obj_process_type = ProcessType.objects.filter(
                        country=area_id,
                        process_type=process_type,
                    ).count()

                    if obj_process_type == 0:
                        p = ProcessType(
                            country=Country.objects.get(pk=area_id),
                            process_type=process_type
                        )
                        p.save()

                    local_tz = pytz.timezone(tz)
                    period_start = datetime.strptime(
                        day['Period']['timeInterval']['start'],
                        "%Y-%m-%dT%H:%MZ"
                    )
                    period_start = local_tz.localize(period_start)
                    count_index = 0
                    quantity = 0

                    for data in day['Period']['Point']:
                        quantity += int(data['quantity'])
                        count_index += 1
                        if count_index == 4:
                            period_start = period_start + timedelta(hours=1)

                            id_process_type = ProcessType.objects.filter(
                                country=area_id,
                                process_type=process_type
                            ).values_list('id', flat=True)[0]

                            data_id = DayAheadData.objects.filter(
                                process_type=ProcessType.objects.get(pk=id_process_type),
                                datetime=period_start,
                            ).values_list('id', flat=True)

                            if len(data_id) == 0:
                                p = DayAheadData(
                                    process_type=ProcessType.objects.get(pk=id_process_type),
                                    datetime=period_start,
                                    data=quantity
                                )
                                p.save()
                            # print(F"quantity = {quantity} | count = {count}")
                            count += 1
                            quantity = 0
                            count_index = 0
            os.remove(files_path + file)

        data = self.getDataDayAhead(areas, 'A01')

        # print(data)

        # response_data['data'] = serializers.serialize("json", data)

        if data == 'none':
            response_data['data'] = data
        else:
            for item in list(data):
                item['date'] = item['datetime'].strftime("%Y-%m-%dT%H:%M:%SZ")
                item.pop('datetime')
            response_data['data'] = list(data)

        return HttpResponse(json.dumps(response_data), content_type="application/json")

    def getDataFromDB(self, area, source):
        try:
            area_id = Country.objects.filter(country=area).values_list('id', flat=True)[0]
        except:
            return 'none'
        source_id = Source.objects.filter(
            country=area_id,
            source=source,
        ).values_list('id', flat=True)[0]
        data = Data.objects.filter(
            source=Source.objects.get(pk=source_id),
        ).values('id', 'datetime', 'data').order_by('datetime')
        return data

    def getDataDayAhead(self, area, process_type):
        try:
            area_id = Country.objects.filter(country=area).values_list('id', flat=True)[0]
        except:
            return 'none'
        process_type_id = ProcessType.objects.filter(
            country=area_id,
            process_type=process_type
        ).values_list('id', flat=True)[0]
        data = DayAheadData.objects.filter(
            process_type=ProcessType.objects.get(pk=process_type_id),
        ).values('id', 'datetime', 'data').order_by('datetime')
        return data